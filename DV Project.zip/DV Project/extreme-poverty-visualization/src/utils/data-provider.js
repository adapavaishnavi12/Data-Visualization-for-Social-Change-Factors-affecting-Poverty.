import * as d3 from 'd3';
import React from 'react';
class RegionChart {

    // constructor() {
    //     if (!this.projectsData) {
    //         this.fetchData();
    //     }
    // }




}

let PovertyContext = React.createContext(new RegionChart());

export default PovertyContext;